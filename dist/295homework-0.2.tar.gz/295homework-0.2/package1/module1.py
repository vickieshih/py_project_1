def function1():
    print("function 1")