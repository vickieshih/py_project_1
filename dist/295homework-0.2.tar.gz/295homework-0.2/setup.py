from distutils.core import setup
setup(
    name = '295homework',
    packages = ['package1', 'package2'],
    version = '0.2',
    description = 'homework',
    author = 'vickieshih',
    author_email = 'vickieshih@pchome.com.tw',
    url = 'https://github.com/vickieshih/py_project_1.git',
    download_url = 'https://github.com/vickieshih/py_project_1/tarball/0.2',
    keywords = ['homework'],
    classifiers = []
)