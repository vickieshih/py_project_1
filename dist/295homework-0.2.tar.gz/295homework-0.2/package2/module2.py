def function2():
    print("function 2")